
CRUSCOTTO TELEMARKETING - VERSIONE AGGIORNATA
==

- Completamente editabile, nessun salvataggio locale.
- Campi mensili: Costi responsabile, strumenti, budget pubblicitario, eventuali, fatturato, ecc.
- Riepilogo e grafici automatici

ISTRUZIONI:
1. Estrai tutti i file in una cartella
2. Carica su GitHub nel tuo repository (vedi README storico)
3. Esegui index.html da browser o pubblica con GitHub Pages
